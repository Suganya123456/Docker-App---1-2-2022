package com.bankManage.management;

import java.util.ArrayList;

import java.util.List;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
@CrossOrigin(origins = "http://localhost:4200")
@SpringBootApplication
@RestController
@RequestMapping(value = "/api/user")
public class BankManagement {

	private List<User> user = new ArrayList<User>();
	
	@RequestMapping(method = RequestMethod.POST)
	public List<User> saveEmployee(@RequestBody User userData) {
		
		this.user.add(userData);
		return this.user;
		}
	
	@RequestMapping(method = RequestMethod.GET)
	public List<User> getEmployee() {
		return this.user;
	}

}
