export class UserDetails {
    username : String = "";
    password : String = "";
    accountNumber : String = "";
    ifscCode : String = "";

    firstName: String = "";
    lastName: String = "";
    accountNo: String = "";
    mobileNo: String = "";
    phoneNo: String = "";
    email: String = "";
    
}