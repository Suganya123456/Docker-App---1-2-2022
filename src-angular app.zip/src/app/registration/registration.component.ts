import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Users } from 'src/app/users.model';
import { UserDetailsService } from 'src/app/user-details.service';
import { UserDetails } from 'src/UserDetails';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
  public userDetail: UserDetails = new UserDetails();

  subscription: Subscription = new Subscription();
  loading = false;
  submitted = false;
  constructor(private router: Router,
   private userDetailsService: UserDetailsService
   ) { }

  ngOnInit(): void {
// this.getUserDetails();
  }
  

  getUserDetails() {
    console.log('registered successfully');
      // this.router.navigate(['./login']);
     }

   
  createUser() {
    console.log('Hello :: ');
      
  this.userDetailsService.registerUsers(this.userDetail).subscribe(response =>{
    console.log(response);
    console.log(JSON.stringify(response));
   // this.router.navigate(['./login']);
   
  });
  this.router.navigate(['']);
  }
     
     
      
  

}